confluence_preset = {
    'config': {
    },
    'metadata': {
        'CONFLUENCE_URL': 'https://confluence.eng.vmware.com'
    }
}
