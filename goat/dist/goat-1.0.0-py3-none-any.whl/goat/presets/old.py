jenkins_preset = {
    'config': {
    },
    'metadata': {
        'JENKINS_URL': 'https://localhost:8080'
    }
}
