#!/usr/bin/env python3
from azure.devops.connection import Connection
from msrest.authentication import BasicAuthentication
import pprint
import requests

# Fill in with your personal access token and org URL
personal_access_token = 'xdyoulo62xf4ljhhs7n5u2qjqyztgdzfog7c5vrt4qtoot3pytjq'
organization_url = 'https://dev.azure.com/baxtercu'  # Updated URL

print("Starting script...")
print(f"Organization URL: {organization_url}")

print("Setting up credentials...")
credentials = BasicAuthentication('', personal_access_token)

try:
    print("Establishing connection...")
    connection = Connection(base_url=organization_url, creds=credentials)
    print("Connection established successfully.")
except Exception as e:
    print(f"Error establishing connection: {e}")
    exit()

try:
    print("Getting core client...")
    core_client = connection.clients.get_core_client()
    print("Core client obtained.")
except Exception as e:
    print(f"Error getting core client: {e}")
    exit()

try:
    print("Getting projects...")
    get_projects_response = core_client.get_projects()
    index = 0
    while get_projects_response:
        for project in get_projects_response:
            pprint.pprint("[" + str(index) + "] " + project.name)
            index += 1
        # Check if there's a continuation token for pagination
        continuation_token = getattr(get_projects_response, 'continuation_token', None)
        if continuation_token:
            get_projects_response = core_client.get_projects(continuation_token=continuation_token)
        else:
            get_projects_response = None
    print("Projects retrieved successfully.")
except Exception as e:
    print(f"Error retrieving projects: {e}")

