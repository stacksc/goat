import datetime
__version__ = datetime.datetime.now().strftime('%Y.%m.%d.%H%M')
