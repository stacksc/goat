# ONLY STORE NON-SENSITIVE INFO IN PRESETS
# CSPTOOLS SHALL NOT HAVE ANY PRESETS FOR PROD DUE TO THE NATURE OF WHAT CSPTOOLS DOES

csp_preset = {
    'metadata': {
        'CSP_URL': 'https://console.cloud-us-gov.vmware.com',
        'VMC_URL': 'https://www.vmc-us-gov.vmware.com'
    }
}
