fly_preset = {
    'config': {
    },
    'metadata': {
        'CONCOURSE_URL': 'https://runway-ci.eng.vmware.com'
    }
}
