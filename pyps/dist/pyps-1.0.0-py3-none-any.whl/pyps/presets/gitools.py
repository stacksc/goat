gitools_preset = {
    'config': {
    },
    'metadata': {
        'GIT_URL': 'https://gitlab.eng.vmware.com'
    }
}
