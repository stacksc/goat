jenkins_preset = {
    'config': {
    },
    'metadata': {
        'JENKINS_URL': 'https://bigsky-ci.eng.vmware.com'
    }
}
