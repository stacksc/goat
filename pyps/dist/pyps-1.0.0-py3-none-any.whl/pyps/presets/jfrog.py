jfrog_preset = {
    'config': {
    },
    'metadata': {
        'ARTIFACTORY_URL': 'https://artifactory.eng.vmware.com'
    }
}
