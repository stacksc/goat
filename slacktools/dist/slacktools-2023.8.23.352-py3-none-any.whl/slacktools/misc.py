# misc functions
def convertTuple(tup):
    # initialize an empty string
    string = ''
    for item in tup:
        string = string + str(item)
    return string
